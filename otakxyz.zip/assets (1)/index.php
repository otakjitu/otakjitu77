<!DOCTYPE html>
<html lang="en">
   <head>
      <title>RTP OTAKJITU | Bocoran RTP dan Pola Slot Gacor</title>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
      <meta name="description" content="RTP OTAKJITU berisi tentang informasi Rtp Slot Tertinggi, Bocoran Slot Gacor Hari Ini dan Pola Slot Gacor Terbaru">
      <meta name="keywords" content="Bocoran RTP Slot Online, RTP Slot Gacor Tertinggi, Pola Slot, Pola Gacor, Bocoran RTP Live Slot, IDN Slot, Slot Online, Hack Slot, Pola Slot Gacor">
      <meta name="author" content="">
      <meta name="language" content="id">
      <meta name="robots" content="index, follow">
      <meta name="geo.placename" content="Indonesia">
      <meta name="geo.country" content="ID">
      <meta name="language" content="ID">
      <meta name="tgn.nation" content="Indonesia">
      <meta name="twitter:card" content="summary">
      <meta name="twitter:site" content="@">
      <meta name="twitter:creator" content="@slot_">
      <meta name="twitter:title" content="RTP OTAKJITU | Bocoran dan Pola Slot Gacor">
      <meta name="twitter:description" content="RTP OTAKJITU berisi tentang informasi Rtp Slot Tertinggi, Bocoran Slot Gacor Hari Ini dan Pola Slot Gacor Terbaru.">
      <meta name="twitter:image" content="https://rtpotakjitu.site/index.html">
      <meta name="theme-color" content="#111c3f">

      <link rel="icon" type="image/png" href="icon-otakjitu.png">
      <link rel="shortcut icon" type="image/png" href="icon-otakjitu.png">
      <link rel="apple-touch-icon" type="image/png" href="icon-otakjitu.png">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css">
      <link rel="stylesheet" href="assets/css/bootstrap.min.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"></script>
   </head>
   <body class="color-1">
      <header class="sticky-top color-2">
         <div class="container px-3 py-2">
            <div class="row no-gutters justify-content-center justify-content-lg-between align-items-center">
               <div class="col col-lg-auto">
                  <div class="logo-wrapper mb-lg-0">
                     <a href="index.html"><img class="web-logo" src="logo-otakjitu-besar.png"></a>
                  </div>
               </div>
               <div class="col-auto">
                  <div class="btn-group w-100">
                     <a href="https://otakjitu.wiki" class="btn btn-regis border-0 text-uppercase d-flex align-items-center py-2">
                     <i class="bi bi-person-plus-fill"></i>
                     <span>DAFTAR</span>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <section>
         <div class="container px-0 px-lg-3 pt-2 py-lg-2">
            <div id="carousel-slider" class="carousel slide" data-ride="carousel">
               <div class="carousel-inner">
                  <div class="carousel-item bg-color-1 active">
                     <img src="banner-otak1.jpg" loading="lazy" class="d-block w-100" alt="RTP Slot">
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section>
         <div class="container bg-transparent px-2 px-lg-3">
            <div class="row no-gutters justify-content-between align-items-center">
               <div class="col pl-lg-0 pr-lg-2">
                  <div class="d-none d-lg-flex color-3 rounded-1 px-2 py-1">
                     <i class="icon bi bi-volume-up-fill"></i>
                     <marquee class="ms-2 text-white">
                        <span>SELAMAT DATANG DI RTP SLOT GACOR TERBARU. RTP SLOT GACOR TERBARU INI HANYA BERLAKU DI SITUS KAMI DAN SEKEDAR REKOMENDASI KAMI! POLA YANG DIBERIKAN SESUAI DENGAN PENGALAMAN BERMAIN KAMI! BUKAN ASAL-ASALAN MEMBERIKAN POLA, SUDAH TERBUKTI DAN LULUS UJI COBA !!</span>
                     </marquee>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section>
         <div class="container px-2 px-lg-3 py-2">
            <div class="row no-gutters">
               <div class="col-12 col-lg-2">
                  <div class="d-block d-lg-none px-0 pb-2">
                     <div class="carousel-game">
                        <div class="row align-items-center py-1">
                           <div class="col">
                              <div class="prev"><i class="icon bi bi-chevron-left"></i></div>
                           </div>
                           <div id="owl-game" class="owl-carousel owl-theme g-1">
                              <div class="item active">
                                 <a href="index.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/pragmaticplay.svg" alt="PragmaticPlay">
                                    </div>
                                    <span>PragmaticPlay</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="pgsoft.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/pgsoft.svg" alt="PGSoft">
                                    </div>
                                    <span>PGSoft</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="habanero.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/habanero.svg" alt="Habanero">
                                    </div>
                                    <span>Habanero</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="microgaming.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/microgaming.svg" alt="Microgaming">
                                    </div>
                                    <span>Microgaming</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="idnslot.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/idnslot.svg" alt="IDNSlot">
                                    </div>
                                    <span>IDNSlot</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="bgaming.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/bgaming.svg" alt="BGaming">
                                    </div>
                                    <span>BGaming</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="gmw.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/gmw.svg" alt="GMW">
                                    </div>
                                    <span>GMW</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="redtiger.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/evolution-redtiger.svg" alt="RedTiger">
                                    </div>
                                    <span>RedTiger</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="btg.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/evolution-btg.svg" alt="BTG">
                                    </div>
                                    <span>BTG</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="spinomenal.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/spinomenal.svg" alt="Spinomenal">
                                    </div>
                                    <span>Spinomenal</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="netent.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/evolution-netent.svg" alt="NetEnt">
                                    </div>
                                    <span>NetEnt</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="felix.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/felix.svg" alt="Felix">
                                    </div>
                                    <span>Felix</span>
                                 </a>
                              </div>
                              <div class="item">
                                 <a href="index.html">
                                    <div class="card-provider">
                                       <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/yggdrasil.svg" alt="YggDrasil">
                                    </div>
                                    <span>YggDrasil</span>
                                 </a>
                              </div>
                           </div>
                           <div class="col">
                              <div class="next"><i class="icon bi bi-chevron-right"></i></div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="d-none d-lg-block color-3 mr-n1">
                     <div class="list-group px-0 py-0">
                        <div class="list-group-item list-group-item-action active px-0 py-0">
                           <a href="/" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/pragmaticplay.svg" alt="PragmaticPlay">
                           <span>PragmaticPlay</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="pgsoft.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/pgsoft.svg" alt="PG Soft">
                           <span>PG Soft</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="habanero.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/habanero.svg" alt="Habanero">
                           <span>Habanero</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="microgaming.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/microgaming.svg" alt="Microgaming">
                           <span>Microgaming</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="idnslot.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/idnslot.svg" alt="IDNSlot">
                           <span>IDNSlot</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="bgaming.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/bgaming.svg" alt="Bgaming">
                           <span>Bgaming</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="gmw.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/gmw.svg" alt="GMW">
                           <span>GMW</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="redtiger.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/evolution-redtiger.svg" alt="RedTiger">
                           <span>RedTiger</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="btg.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/evolution-btg.svg" alt="BTG">
                           <span>BTG</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="spinomenal.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/spinomenal.svg" alt="Spinomenal">
                           <span>Spinomenal</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="netent.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/evolution-netent.svg" alt="NetEnt">
                           <span>NetEnt</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="felix.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/felix.svg" alt="Felix">
                           <span>Felix</span>
                           </a>
                        </div>
                        <div class="list-group-item list-group-item-action px-0 py-0">
                           <a href="index.html" class="d-flex justify-content-start align-items-center px-2 py-2">
                           <img class="provider-thumbnail" src="https://dmwl0ca1bvnm.cloudfront.net/common/dark/slot/yggdrasil.svg" alt="Yggdrasil">
                           <span>Yggdrasil</span>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-12 col-lg-10">
                  <div class="rtp-wrapper bg-color-3 ml-lg-3">
                     <div class="rtp-header row g-0 color-3 py-1 px-2 align-items-center">
                        <div class="col-sm text-center">
                           <h4 class="text-xs-left m-0">
                              <span class="animate-charcter">RTP SLOT : PRAGMATICPLAY</span>
                           </h4>
                        </div>
                        <div class="col-sm-4 py-1">
                           <input class="form-control form-control-sm mr-sm-2" type="search" placeholder="Cari game" aria-label="Search" id="search">
                        </div>
                     </div>
                     <div class="rtp-body px-2 py-1">
                        <div class="card-deck row row-col-5 no-gutters">
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4982/thumbnail.jpg" alt="Gates of Aztec">
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Gates of Aztec</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4978/thumbnail.jpg" alt="5 Rabbits Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">5 Rabbits Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4984/thumbnail.jpg" alt="PIZZA! PIZZA? PIZZA!">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">PIZZA! PIZZA? PIZZA!</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/824/thumbnail.jpeg" alt="Gates of Olympus">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Gates of Olympus</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/727/thumbnail.jpeg" alt="Sweet Bonanza">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Sweet Bonanza</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/726/thumbnail.jpeg" alt="Aztec Gems">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Aztec Gems</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/732/thumbnail.jpeg" alt="Sweet Bonanza Xmas">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Sweet Bonanza Xmas</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2845/thumbnail.jpg" alt="Starlight Princess">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Starlight Princess</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/729/thumbnail.jpeg" alt="Wild West Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wild West Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4746/thumbnail.jpg" alt="Sugar Rush™">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Sugar Rush™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/733/thumbnail.jpeg" alt="Bonanza Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Bonanza Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/728/thumbnail.jpeg" alt="Joker's Jewels">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Joker's Jewels</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2846/thumbnail.jpg" alt="Pyramid Bonanza">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Pyramid Bonanza</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/730/thumbnail.jpeg" alt="Aztec Gems Deluxe">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Aztec Gems Deluxe</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/731/thumbnail.jpeg" alt="Great Rhino Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Great Rhino Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/785/thumbnail.jpeg" alt="Wolf Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wolf Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/813/thumbnail.jpeg" alt="5 Lions Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">5 Lions Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/837/thumbnail.jpeg" alt="Power of Thor Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Power of Thor Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/755/thumbnail.jpeg" alt="888 Dragons">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">888 Dragons</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/849/thumbnail.jpeg" alt="Fruit Party">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fruit Party</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/744/thumbnail.jpeg" alt="Madame Destiny Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Madame Destiny Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/737/thumbnail.jpeg" alt="Diamond Strike">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Diamond Strike</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/749/thumbnail.jpeg" alt="Gems Bonanza">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Gems Bonanza</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/816/thumbnail.jpeg" alt="Buffalo King Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Buffalo King Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/738/thumbnail.jpeg" alt="The Dog House Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">The Dog House Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/746/thumbnail.jpeg" alt="Fire 88">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fire 88</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/941/thumbnail.jpeg" alt="Roulette">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Roulette</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/735/thumbnail.jpeg" alt="The Dog House">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">The Dog House</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/756/thumbnail.jpeg" alt="Mustang Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Mustang Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/734/thumbnail.jpeg" alt="Fire Strike">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fire Strike</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/754/thumbnail.jpeg" alt="Big Bass Bonanza">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Big Bass Bonanza</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/827/thumbnail.jpeg" alt="Hot Fiesta">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Hot Fiesta</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2949/thumbnail.jpg" alt="Candy Village">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Candy Village</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/745/thumbnail.jpeg" alt="Christmas Carol Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Christmas Carol Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/764/thumbnail.jpeg" alt="5 Lions">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">5 Lions</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/742/thumbnail.jpeg" alt="John Hunter and the Tomb of the Scarab Queen">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">John Hunter and the Tomb of the Scarab Queen</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/751/thumbnail.jpeg" alt="8 Dragons">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">8 Dragons</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/739/thumbnail.jpeg" alt="Great Rhino">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Great Rhino</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/795/thumbnail.jpeg" alt="Lucky New Year">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Lucky New Year</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/741/thumbnail.jpeg" alt="Aztec Bonanza">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Aztec Bonanza</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/780/thumbnail.jpeg" alt="Caishen's Cash">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Caishen's Cash</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/769/thumbnail.jpeg" alt="Caishen's Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Caishen's Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/840/thumbnail.jpg" alt="The Hand of Midas">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">The Hand of Midas</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/766/thumbnail.jpeg" alt="Triple Tigers">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Triple Tigers</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/752/thumbnail.jpeg" alt="Great Rhino Deluxe">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Great Rhino Deluxe</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/776/thumbnail.jpeg" alt="Monkey Madness">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Monkey Madness</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/800/thumbnail.jpeg" alt="Egyptian Fortunes">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Egyptian Fortunes</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/796/thumbnail.jpeg" alt="Lady Godiva">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Lady Godiva</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/753/thumbnail.jpeg" alt="Extra Juicy">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Extra Juicy</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/898/thumbnail.jpeg" alt="Jade Butterfly">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Jade Butterfly</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/846/thumbnail.jpeg" alt="Treasure Horse">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Treasure Horse</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/768/thumbnail.jpeg" alt="Chilli Heat">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Chilli Heat</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/774/thumbnail.jpeg" alt="Golden Pig">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Golden Pig</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/804/thumbnail.jpeg" alt="Journey to the West">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Journey to the West</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/736/thumbnail.jpeg" alt="Panda's Fortune">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Panda's Fortune</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/765/thumbnail.jpeg" alt="3 Kingdoms - Battle of Red Cliffs">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">3 Kingdoms - Battle of Red Cliffs</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/1299/thumbnail.jpeg" alt="Fruit Party 2">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fruit Party 2</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/832/thumbnail.jpeg" alt="Lucky Lightning">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Lucky Lightning</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/878/thumbnail.jpeg" alt="3 Genie Wishes">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">3 Genie Wishes</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/762/thumbnail.jpeg" alt="5 Lions Dance">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">5 Lions Dance</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="//bhidn-dk2.pragmaticplay.net/game_pic/rec/188/vs243lionsgold.png" alt="5 Lions Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">5 Lions Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/865/thumbnail.jpeg" alt="7 Monkeys">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">7 Monkeys</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/854/thumbnail.jpeg" alt="7 Piggies">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">7 Piggies</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/777/thumbnail.jpeg" alt="888 Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">888 Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/901/thumbnail.jpeg" alt="Aladdin and the Sorcerer">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Aladdin and the Sorcerer</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/814/thumbnail.jpeg" alt="Amazing Money Machine">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Amazing Money Machine</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/920/thumbnail.jpeg" alt="American Blackjack">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">American Blackjack</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/893/thumbnail.jpeg" alt="Ancient Egypt">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Ancient Egypt</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/760/thumbnail.jpeg" alt="Ancient Egypt Classic">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Ancient Egypt Classic</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/843/thumbnail.jpeg" alt="Asgard">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Asgard</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/815/thumbnail.jpeg" alt="Aztec King">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Aztec King</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/868/thumbnail.jpeg" alt="Aztec Treasure">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Aztec Treasure</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/939/thumbnail.jpeg" alt="Baccarat">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Baccarat</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/805/thumbnail.jpeg" alt="Book Of Kingdoms">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Book Of Kingdoms</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/806/thumbnail.jpeg" alt="Book of Tut">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Book of Tut</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/770/thumbnail.jpeg" alt="Bronco Spirit">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Bronco Spirit</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/743/thumbnail.jpeg" alt="Buffalo King">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Buffalo King</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/811/thumbnail.jpeg" alt="Busy Bees">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Busy Bees</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/817/thumbnail.jpeg" alt="Cash Elevator">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Cash Elevator</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/1414/thumbnail.jpg" alt="Chicken Drop">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Chicken Drop</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/761/thumbnail.jpeg" alt="Congo Cash">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Congo Cash</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/757/thumbnail.jpeg" alt="Cowboys Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Cowboys Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/859/thumbnail.jpeg" alt="Curse of the Werewolf Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Curse of the Werewolf Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/887/thumbnail.jpeg" alt="Da Vinci's Treasure">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Da Vinci's Treasure</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="//bhidn-dk2.pragmaticplay.net/game_pic/rec/188/vs243dancingpar.png" alt="Dance Party">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Dance Party</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/899/thumbnail.jpeg" alt="Devil's 13">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Devil's 13</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/864/thumbnail.jpeg" alt="Diamonds are Forever 3 Lines">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Diamonds are Forever 3 Lines</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/793/thumbnail.jpeg" alt="Drago - Jewels of Fortune">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Drago - Jewels of Fortune</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/922/thumbnail.jpeg" alt="Dragon Bonus Baccarat">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Dragon Bonus Baccarat</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/818/thumbnail.jpeg" alt="Dragon Hot Hold &amp; Spin">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Dragon Hot Hold &amp; Spin</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/792/thumbnail.jpeg" alt="Dragon Kingdom">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Dragon Kingdom</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/782/thumbnail.jpeg" alt="Dragon Kingdom - Eyes of Fire">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Dragon Kingdom - Eyes of Fire</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/921/thumbnail.jpeg" alt="Dragon Tiger">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Dragon Tiger</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/876/thumbnail.jpeg" alt="Dwarven Gold Deluxe">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Dwarven Gold Deluxe</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/848/thumbnail.jpeg" alt="Emerald King">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Emerald King</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/810/thumbnail.jpeg" alt="Emerald King Rainbow Road">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Emerald King Rainbow Road</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/767/thumbnail.jpeg" alt="Eye of the Storm">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Eye of the Storm</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/860/thumbnail.jpeg" alt="Fairytale Fortune">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fairytale Fortune</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="//bhidn-dk2.pragmaticplay.net/game_pic/rec/188/vs10goldfish.png" alt="Fishin Reels">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fishin Reels</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/822/thumbnail.jpeg" alt="Floating Dragon">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Floating Dragon</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4883/thumbnail.jpg" alt="Down the Rails">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Down the Rails</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4888/thumbnail.jpg" alt="Black Bull">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Black Bull</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/847/thumbnail.jpeg" alt="Fruit Rainbow">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fruit Rainbow</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/870/thumbnail.jpeg" alt="Fu Fu Fu">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fu Fu Fu</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/809/thumbnail.jpeg" alt="Gold Rush">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Gold Rush</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/853/thumbnail.jpeg" alt="Gold Train">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Gold Train</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/759/thumbnail.jpeg" alt="Golden Beauty">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Golden Beauty</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/740/thumbnail.jpeg" alt="Golden Ox">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Golden Ox</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/863/thumbnail.jpeg" alt="Great Reef">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Great Reef</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/802/thumbnail.jpeg" alt="Greek Gods">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Greek Gods</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/825/thumbnail.jpeg" alt="Heart of Rio">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Heart of Rio</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/845/thumbnail.jpeg" alt="Hercules and Pegasus">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Hercules and Pegasus</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/895/thumbnail.jpeg" alt="Hercules Son of Zeus">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Hercules Son of Zeus</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/826/thumbnail.jpeg" alt="Hokkaido Wolf">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Hokkaido Wolf</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/873/thumbnail.jpeg" alt="Honey Honey Honey">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Honey Honey Honey</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/883/thumbnail.jpeg" alt="Hot Chilli">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Hot Chilli</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/861/thumbnail.jpeg" alt="Hot Safari">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Hot Safari</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/790/thumbnail.jpeg" alt="Hot to Burn">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Hot to Burn</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/828/thumbnail.jpeg" alt="Hot to Burn Hold and Spin">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Hot to Burn Hold and Spin</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/885/thumbnail.jpeg" alt="Irish Charms">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Irish Charms</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/801/thumbnail.jpeg" alt="John Hunter And The Mayan Gods">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">John Hunter And The Mayan Gods</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/829/thumbnail.jpeg" alt="Joker King">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Joker King</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/830/thumbnail.jpeg" alt="Juicy Fruits">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Juicy Fruits</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/889/thumbnail.jpeg" alt="Jungle Gorilla">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Jungle Gorilla</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/875/thumbnail.jpeg" alt="Leprechaun Carol">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Leprechaun Carol</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/892/thumbnail.jpeg" alt="Leprechaun Song">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Leprechaun Song</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/807/thumbnail.jpeg" alt="Lucky Dragon Ball">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Lucky Dragon Ball</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/879/thumbnail.jpeg" alt="Lucky Dragons">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Lucky Dragons</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/881/thumbnail.jpeg" alt="Madame Destiny">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Madame Destiny</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="//bhidn-dk2.pragmaticplay.net/game_pic/rec/188/vs8magicjourn.png" alt="Magic Journey">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Magic Journey</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/867/thumbnail.jpeg" alt="Master Chen's Fortune">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Master Chen's Fortune</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/783/thumbnail.jpeg" alt="Master Joker">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Master Joker</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/851/thumbnail.jpeg" alt="Mighty Kong">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Mighty Kong</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/779/thumbnail.jpeg" alt="Money Money Money">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Money Money Money</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/786/thumbnail.jpeg" alt="Money Mouse">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Money Mouse</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/866/thumbnail.jpeg" alt="Money Roll">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Money Roll</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/775/thumbnail.jpeg" alt="Monkey Warrior">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Monkey Warrior</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/940/thumbnail.jpeg" alt="Multihand Blackjack">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Multihand Blackjack</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/858/thumbnail.jpeg" alt="Mysterious">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Mysterious</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/787/thumbnail.jpeg" alt="Mysterious Egypt">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Mysterious Egypt</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/834/thumbnail.jpeg" alt="Panda Fortune 2">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Panda Fortune 2</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/855/thumbnail.jpeg" alt="Peking Luck">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Peking Luck</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/758/thumbnail.jpeg" alt="Pirate Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Pirate Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/844/thumbnail.jpeg" alt="Pirate Gold Deluxe">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Pirate Gold Deluxe</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/836/thumbnail.jpeg" alt="Pixie Wings">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Pixie Wings</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/772/thumbnail.jpeg" alt="Pyramid King">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Pyramid King</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/871/thumbnail.jpeg" alt="Queen of Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Queen of Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/784/thumbnail.jpeg" alt="Release the Kraken">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Release the Kraken</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/794/thumbnail.jpeg" alt="Return of the Dead">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Return of the Dead</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/798/thumbnail.jpeg" alt="Rise of Samurai">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Rise of Samurai</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/838/thumbnail.jpeg" alt="Rise of Samurai Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Rise of Samurai Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/886/thumbnail.jpeg" alt="Safari King">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Safari King</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/872/thumbnail.jpeg" alt="Santa">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Santa</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/799/thumbnail.jpeg" alt="Spartan King">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Spartan King</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/788/thumbnail.jpeg" alt="Star Bounty">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Star Bounty</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/850/thumbnail.jpeg" alt="Starz Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Starz Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/891/thumbnail.jpeg" alt="Street Racer">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Street Racer</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/773/thumbnail.jpeg" alt="Super 7s">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Super 7s</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/803/thumbnail.jpeg" alt="Super Joker">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Super Joker</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/839/thumbnail.jpeg" alt="Temujin Treasures">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Temujin Treasures</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/852/thumbnail.jpeg" alt="The Great Chicken Escape">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">The Great Chicken Escape</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/841/thumbnail.jpeg" alt="The Magic Cauldron">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">The Magic Cauldron</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/797/thumbnail.jpeg" alt="The Tiger Warrior">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">The Tiger Warrior</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/857/thumbnail.jpeg" alt="The Wild Machine">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">The Wild Machine</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/812/thumbnail.jpeg" alt="Three Star Fortune">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Three Star Fortune</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/778/thumbnail.jpeg" alt="Tree of Riches">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Tree of Riches</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/856/thumbnail.jpeg" alt="Triple Dragons">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Triple Dragons</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/791/thumbnail.jpeg" alt="Ultra Burn">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Ultra Burn</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/747/thumbnail.jpeg" alt="Ultra Hold and Spin">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Ultra Hold and Spin</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/880/thumbnail.jpeg" alt="Vampires vs Wolves">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Vampires vs Wolves</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/750/thumbnail.jpeg" alt="Vegas Magic">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Vegas Magic</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/874/thumbnail.jpeg" alt="Vegas Nights">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Vegas Nights</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/808/thumbnail.jpeg" alt="Voodoo Magic">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Voodoo Magic</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/842/thumbnail.jpeg" alt="Wild Booster">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wild Booster</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/888/thumbnail.jpeg" alt="Wild Gladiator">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wild Gladiator</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/862/thumbnail.jpeg" alt="Wild Pixies">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wild Pixies</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/781/thumbnail.jpeg" alt="Wild Spells">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wild Spells</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/884/thumbnail.jpeg" alt="Wild Walker">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wild Walker</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/763/thumbnail.jpeg" alt="Wild Wild Riches">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wild Wild Riches</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/835/thumbnail.jpeg" alt="Phoenix Forge">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Phoenix Forge</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/819/thumbnail.jpeg" alt="Empty the Bank">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Empty the Bank</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2840/thumbnail.jpg" alt="Aztec King Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Aztec King Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2842/thumbnail.jpg" alt="Lucky Grace And Charm">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Lucky Grace And Charm</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2305/thumbnail.jpeg" alt="Yum Yum Powerways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Yum Yum Powerways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2843/thumbnail.jpg" alt="Chilli Heat Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Chilli Heat Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2848/thumbnail.jpg" alt="Rise of Giza PowerNudge">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Rise of Giza PowerNudge</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2847/thumbnail.jpg" alt="Raging Bull">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Raging Bull</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2878/thumbnail.jpg" alt="Bigger Bass Bonanza">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Bigger Bass Bonanza</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2892/thumbnail.jpg" alt="Treasure Wild">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Treasure Wild</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2908/thumbnail.jpg" alt="Piggy Bank Bills">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Piggy Bank Bills</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2927/thumbnail.jpg" alt="Cash Bonanza">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Cash Bonanza</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2951/thumbnail.jpg" alt="Day of Dead">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Day of Dead</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2956/thumbnail.jpg" alt="The Tweety House">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">The Tweety House</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2957/thumbnail.jpg" alt="Mystic Chief">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Mystic Chief</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2976/thumbnail.jpg" alt="Star Pirates Code">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Star Pirates Code</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2962/thumbnail.jpg" alt="Big Juan">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Big Juan</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/2987/thumbnail.jpg" alt="John Hunter and the Quest for Bermuda Riches">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">John Hunter and the Quest for Bermuda Riches</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3618/thumbnail.jpg" alt="Santa's Wonderland">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Santa's Wonderland</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3627/thumbnail.jpg" alt="Christmas Big Bass Bonanza">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Christmas Big Bass Bonanza</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3628/thumbnail.jpg" alt="Bounty Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Bounty Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3650/thumbnail.jpg" alt="Hockey Attack">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Hockey Attack</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3651/thumbnail.jpg" alt="Big Bass Bonanza Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Big Bass Bonanza Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3703/thumbnail.jpg" alt="Super X">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Super X</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3702/thumbnail.jpg" alt="Fortune of Giza">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fortune of Giza</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3731/thumbnail.jpg" alt="Emperor Caishen">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Emperor Caishen</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3751/thumbnail.jpg" alt="Lucky New Year Tiger Treasures">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Lucky New Year Tiger Treasures</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3746/thumbnail.jpg" alt="Crystal Caverns Megaways">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Crystal Caverns Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3747/thumbnail.jpg" alt="Smugglers Cove">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Smugglers Cove</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3755/thumbnail.png" alt="Magician's Secrets">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Magician's Secrets</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3845/thumbnail.jpg" alt="Extra Juicy Megaways™">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Extra Juicy Megaways™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3750/thumbnail.jpg" alt="Wild Depths">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wild Depths</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3849/thumbnail.jpg" alt="Gates of Valhalla™">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Gates of Valhalla™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3851/thumbnail.jpg" alt="Gold Party">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Gold Party</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3959/thumbnail.png" alt="Elemental Gems Megaways™">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Elemental Gems Megaways™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3962/thumbnail.jpg" alt="Rock Vegas™">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Rock Vegas™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3968/thumbnail.png" alt="Cash Patrol">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Cash Patrol</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3960/thumbnail.jpg" alt="Rainbow Gold">  
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Rainbow Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3976/thumbnail.jpg" alt="The Ultimate 5™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">The Ultimate 5™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3957/thumbnail.png" alt="Wild Beach Party"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wild Beach Party</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3974/thumbnail.jpg" alt="Colossal Cash Zone™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Colossal Cash Zone™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3978/thumbnail.png" alt="Book of Aztec King™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Book of Aztec King™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4406/thumbnail.png" alt="Bull Fiesta"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Bull Fiesta</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4407/thumbnail.png" alt="Might of Ra"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Might of Ra</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4579/thumbnail.jpg" alt="Snakes and Ladders Megadice™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Snakes and Ladders Megadice™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4587/thumbnail.jpg" alt="Barn Festival"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Barn Festival</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3977/thumbnail.png" alt="Queenie™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Queenie™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/3982/thumbnail.png" alt="Disco Lady™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Disco Lady™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4578/thumbnail.jpg" alt="Tic Tac Take"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Tic Tac Take</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4613/thumbnail.jpg" alt="Chicken Chase"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Chicken Chase</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4614/thumbnail.jpg" alt="Wild West Gold Megaways"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wild West Gold Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4623/thumbnail.jpg" alt="Clover Gold"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Clover Gold</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4584/thumbnail.jpg" alt="Drill That Gold™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Drill That Gold™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4583/thumbnail.jpg" alt="Spirit of Adventure™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Spirit of Adventure™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4698/thumbnail.jpg" alt="Fire Strike 2"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fire Strike 2</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4703/thumbnail.jpg" alt="Eye of Cleopatra"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Eye of Cleopatra</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4706/thumbnail.jpg" alt="Goblin Heist Powernudge"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Goblin Heist Powernudge</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4716/thumbnail.jpg" alt="Zombie Carnival™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Zombie Carnival™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4741/thumbnail.jpg" alt="Koi Pond"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Koi Pond</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4701/thumbnail.jpg" alt="North Guardians™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">North Guardians™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4700/thumbnail.jpg" alt="The Great Stick-up™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">The Great Stick-up™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4740/thumbnail.jpg" alt="Rise of Samurai III"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Rise of Samurai III</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4745/thumbnail.jpg" alt="Cleocatra"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Cleocatra</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4748/thumbnail.jpg" alt="Little Gem"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Little Gem</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4774/thumbnail.jpg" alt="Cosmic Cash"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Cosmic Cash</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4807/thumbnail.jpg" alt="Bomb Bonanza"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Bomb Bonanza</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4739/thumbnail.jpg" alt="Queen of Gods™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Queen of Gods™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4747/thumbnail.jpg" alt="Mahjong Panda™"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Mahjong Panda™</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4815/thumbnail.jpg" alt="Big Bass Splash"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Big Bass Splash</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4821/thumbnail.jpg" alt="Coffee Wild"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Coffee Wild</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4824/thumbnail.jpg" alt="Shining Hot 5"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Shining Hot 5</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4823/thumbnail.jpg" alt="Shining Hot 20"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Shining Hot 20</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4822/thumbnail.jpg" alt="Shining Hot 40"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Shining Hot 40</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4825/thumbnail.jpg" alt="Shining Hot 100"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Shining Hot 100</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4838/thumbnail.jpg" alt="Hot to Burn Extreme"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Hot to Burn Extreme</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4814/thumbnail.jpg" alt="Tropical Tiki"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Tropical Tiki</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4844/thumbnail.jpg" alt="Octobeer Fortunes"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Octobeer Fortunes</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4843/thumbnail.jpg" alt="Gorilla Mayhem"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Gorilla Mayhem</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4837/thumbnail.jpg" alt="Cheeky Emperor"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Cheeky Emperor</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4874/thumbnail.jpg" alt="Fire Hot 5"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fire Hot 5</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4875/thumbnail.jpg" alt="Fire Hot 20"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fire Hot 20</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4876/thumbnail.jpg" alt="Fire Hot 40"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fire Hot 40</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4877/thumbnail.jpg" alt="Fire Hot 100"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Fire Hot 100</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4873/thumbnail.jpg" alt="Greedy Wolf"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Greedy Wolf</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4882/thumbnail.jpg" alt="Magic Money Maze"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Magic Money Maze</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4832/thumbnail.jpg" alt="Wildman Super Bonanza"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wildman Super Bonanza</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4833/thumbnail.jpg" alt="Floating Dragon Megaways"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Floating Dragon Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4889/thumbnail.jpg" alt="Candy Stars"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Candy Stars</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4896/thumbnail.jpg" alt="Muertos Multiplier Megaways"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Muertos Multiplier Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4897/thumbnail.jpg" alt="Crown of Fire"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Crown of Fire</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4911/thumbnail.jpg" alt="Snakes &amp; Ladders 2 - Snake Eyes"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Snakes &amp; Ladders 2 - Snake Eyes</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4912/thumbnail.jpg" alt="Striking Hot 5"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Striking Hot 5</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4914/thumbnail.jpg" alt="Book of Golden Sands"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Book of Golden Sands</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4886/thumbnail.png" alt="Wild Hop &amp; Drop"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Wild Hop &amp; Drop</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4885/thumbnail.png" alt="Legend of Heroes Megaways"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Legend of Heroes Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4919/thumbnail.jpg" alt="Sword of Ares"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Sword of Ares</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4922/thumbnail.jpg" alt="Old Gold Miner Megaways"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Old Gold Miner Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4938/thumbnail.jpg" alt="John Hunter &amp; the Book of Tut Respin"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">John Hunter &amp; the Book of Tut Respin</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4943/thumbnail.jpg" alt="Kingdom of Asgard"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Kingdom of Asgard</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4944/thumbnail.jpg" alt="Bigger Bass Blizzard - Christmas Catch"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Bigger Bass Blizzard - Christmas Catch</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4918/thumbnail.jpg" alt="Aztec Blaze"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Aztec Blaze</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4959/thumbnail.jpg" alt="Release the Kraken 2"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Release the Kraken 2</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4960/thumbnail.jpg" alt="Santa's Great Gift"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Santa's Great Gift</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4969/thumbnail.jpg" alt="Towering Fortunes"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Towering Fortunes</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4970/thumbnail.jpg" alt="Firebird Spirit"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Firebird Spirit</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4968/thumbnail.jpg" alt="Starlight Christmas"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Starlight Christmas</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4973/thumbnail.jpg" alt="Pirate Golden Age"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Pirate Golden Age</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4972/thumbnail.jpg" alt="Gems of Serengeti"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Gems of Serengeti</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4917/thumbnail.jpg" alt="Spin &amp; Score Megaways"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Spin &amp; Score Megaways</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4977/thumbnail.jpg" alt="Big Bass - Keeping it Reel"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Big Bass - Keeping it Reel</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4950/thumbnail.jpg" alt="Shield of Sparta"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Shield of Sparta</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4966/thumbnail.jpg" alt="Gates of Gatot Kaca"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Gates of Gatot Kaca</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4976/thumbnail.jpg" alt="Lucky Fishing"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Lucky Fishing</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4979/thumbnail.jpg" alt="Dragon Hero"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Dragon Hero</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="card card-game d-flex">
                              <div class="game-link">
                                 <a class="btn btn-game text-uppercase" onclick="login()">MAIN</a>
                              </div>
                              <div class="game-item">
                                 <img class="game-item-img" loading="lazy" src="https://d3ejb2l5e3bvmc.cloudfront.net/game-images/pragmaticplay/4985/thumbnail.jpg" alt="Reel Banks"> 
                              </div>
                              <div class="percent">
                                 <p id="percent-txt" class="percent-txt" style="z-index: 15"></p>
                                 <div id="percent-bar" class="percent-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="" style="width: 0"></div>
                              </div>
                              <span class="card-title">Reel Banks</span>
                              <div class="jam">
                                 <div class="jamgacor jamBg">
                                    <h5 class="jamgacorRange">XX - XX</h5>
                                 </div>
                                 <div class="pola jamBg">
                                    <h5>POLA MAIN</h5>
                                    <p class="pola1"></p>
                                    <p class="pola2"></p>
                                    <p class="pola3"></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <script src="assets/js/slot.js"></script>

      <footer>
         <div class="container bg-gradient-dark px-3 py-3">
            <p class="text-white text-center font-weight-bold mb-0"><span>Copyright &copy; 2022, All rights reserved.</span></p>
         </div>
      </footer>
      <script type="text/javascript">
         $(document).ready(function() {
             var owl = $("#owl-game");
             owl.owlCarousel({
                 autoplay: true,
                 loop:true,
                     autoplayTimeout: 3000,
                     navigation: false,
                     margin: 10,
                     responsive: {
                         0: {
                             items: 3
                         },
                         600: {
                             items: 5
                         },
                         1000: {
                             items: 6
                         }
                     }
             })
         });
         
         jQuery.expr[':'].contains = function(a, i, m) {
             return jQuery(a).text().toUpperCase()
             .indexOf(m[3].toUpperCase()) >= 0;
         };
         $('#search').keyup(function (){
             $('.card').removeClass('d-none');
             var filter = $(this).val(); 
             $('.card-deck').find('.card span:not(:contains("'+filter+'"))').parent().addClass('d-none');
         })
         $('#btnSort').click(function (){
             $('.card-deck .card').sort(function(a,b) {
                 return $(a).find(".card-title").text() > $(b).find(".card-title").text() ? 1 : -1;
             }).appendTo(".card-deck");
         })
         function login() {
             window.open("https://otakjitu.wiki", "_blank");
         }
      </script>
<!-- Start of LiveChat (www.livechat.com) code -->
<script>
    window.__lc = window.__lc || {};
    window.__lc.license = 18118779;
    window.__lc.integration_name = "manual_channels";
    window.__lc.product_name = "livechat";
    ;(function(n,t,c){function i(n){return e._h?e._h.apply(null,n):e._q.push(n)}var e={_q:[],_h:null,_v:"2.0",on:function(){i(["on",c.call(arguments)])},once:function(){i(["once",c.call(arguments)])},off:function(){i(["off",c.call(arguments)])},get:function(){if(!e._h)throw new Error("[LiveChatWidget] You can't use getters before load.");return i(["get",c.call(arguments)])},call:function(){i(["call",c.call(arguments)])},init:function(){var n=t.createElement("script");n.async=!0,n.type="text/javascript",n.src="https://cdn.livechatinc.com/tracking.js",t.head.appendChild(n)}};!n.__lc.asyncInit&&e.init(),n.LiveChatWidget=n.LiveChatWidget||e}(window,document,[].slice))
</script>
<noscript><a href="https://www.livechat.com/chat-with/18118779/" rel="nofollow">Chat with us</a>, powered by <a href="https://www.livechat.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a></noscript>
<!-- End of LiveChat code -->


      <div style="position: fixed; bottom: 90px; right: 10px; z-index: 10; opacity: 0.98;">
<a href="https://direct.lc.chat/15037692/" target="_blank" rel="nofollow noopener">
<img class="rtp" src="https://i.imgur.com/vTZrFVH.png" alt="OTAKJITU livechat" width="80" height="100"></a></div>
   </body>
</html>